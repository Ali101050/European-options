import math
import unittest
from dataclasses import replace
from black_scholes import Inputs,price,greeks,implied_volatility,binomial,monte_carlo

class PricingTests(unittest.TestCase):
    def setUp(self): self.p=Inputs(100,100,1,.05,.2)
    def test_known_values(self):
        self.assertAlmostEqual(price(self.p),10.4505835721856,places=10)
        self.assertAlmostEqual(price(self.p,'put'),5.57352602225697,places=10)
    def test_parity_and_bounds_grid(self):
        for s in (20,100,250):
            for t in (.01,.5,2):
                for r in (-.03,.05):
                    for v in (.01,.2,.8):
                        for q in (0,.04):
                            p=Inputs(s,100,t,r,v,q)
                            c,u=price(p),price(p,'put')
                            a,b=s*math.exp(-q*t),100*math.exp(-r*t)
                            self.assertAlmostEqual(c-u,a-b,places=10)
                            self.assertTrue(max(a-b,0)-1e-10 <= c <= a+1e-10)
                            self.assertTrue(max(b-a,0)-1e-10 <= u <= b+1e-10)
    def test_degenerate_limits(self):
        self.assertEqual(price(replace(self.p,time=0,spot=110)),10)
        self.assertAlmostEqual(price(replace(self.p,volatility=0)),100-100*math.exp(-.05))
        self.assertEqual(price(replace(self.p,time=0,spot=90),'put'),10)
    def test_invalid_inputs(self):
        for kw in ({'spot':0},{'strike':-1},{'time':-1},{'volatility':-1},{'rate':float('nan')},{'spot':True}):
            with self.assertRaises(ValueError): replace(self.p,**kw)
        with self.assertRaises(ValueError): price(self.p,'asian')
        with self.assertRaises(ValueError): greeks(replace(self.p,time=0))
        with self.assertRaises(ValueError): binomial(self.p,steps=0)
        with self.assertRaises(ValueError): monte_carlo(self.p,samples=1)
    def test_greeks_finite_differences(self):
        p=replace(self.p,dividend=.03)
        for kind in ('call','put'):
            g=greeks(p,kind)
            for field,name,h in [('spot','delta',.001),('volatility','vega',.00001),('rate','rho',.00001),('time','theta',.00001)]:
                x=getattr(p,field)
                fd=(price(replace(p,**{field:x+h}),kind)-price(replace(p,**{field:x-h}),kind))/(2*h)
                if name=='theta': fd=-fd
                self.assertAlmostEqual(g[name],fd,places=6)
            h=.01
            gamma=(price(replace(p,spot=p.spot+h),kind)-2*price(p,kind)+price(replace(p,spot=p.spot-h),kind))/h**2
            self.assertAlmostEqual(g['gamma'],gamma,places=6)
    def test_implied_volatility(self):
        for kind in ('call','put'):
            for v in (.08,.2,.8,1.5):
                p=replace(self.p,volatility=v,dividend=.02)
                self.assertAlmostEqual(implied_volatility(p,price(p,kind),kind),v,places=8)
        for target in (-1,100):
            with self.assertRaises(ValueError): implied_volatility(self.p,target)
        with self.assertRaises(ValueError): implied_volatility(replace(self.p,time=0),0)
    def test_tree_accuracy(self):
        for kind in ('call','put'):
            self.assertLess(abs(binomial(self.p,kind,1000)-price(self.p,kind)),.003)
    def test_simulation_reproducibility(self):
        a=monte_carlo(self.p,samples=20000,seed=7)
        self.assertEqual(a,monte_carlo(self.p,samples=20000,seed=7))
        self.assertLess(abs(a['estimate']-price(self.p)),4*a['standard_error'])
    def test_monotonicity(self):
        self.assertGreater(price(replace(self.p,spot=110)),price(self.p))
        for kind in ('call','put'):
            self.assertGreater(price(replace(self.p,volatility=.3),kind),price(self.p,kind))

if __name__=='__main__': unittest.main(verbosity=2)
