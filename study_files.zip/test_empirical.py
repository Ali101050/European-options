import unittest
import numpy as np
import pandas as pd
from run_analysis import features,maturity,metrics,block_bootstrap

class EmpiricalTests(unittest.TestCase):
    def data(self):
        dates=pd.bdate_range('2026-01-01',periods=100)
        u=pd.DataFrame({'date':dates,'close':100*np.exp(np.sin(np.arange(100)/3)*.02+np.arange(100)*.001)})
        r=pd.DataFrame({'date':dates,'close':4.0})
        return u,r
    def test_no_future_leakage(self):
        u,r=self.data();a=features(u,r);u.loc[80:,'close']*=5;r.loc[80:,'close']=20;b=features(u,r)
        for column in ('hv20','hv60','rate'):
            np.testing.assert_allclose(a.loc[:79,column],b.loc[:79,column],equal_nan=True)
    def test_current_return_is_excluded(self):
        u,r=self.data();a=features(u,r);u.loc[70,'close']*=2;b=features(u,r)
        self.assertAlmostEqual(a.loc[70,'hv20'],b.loc[70,'hv20'])
        self.assertNotEqual(a.loc[71,'hv20'],b.loc[71,'hv20'])
    def test_rates_strictly_lagged(self):
        u,r=self.data();x=features(u,r)
        valid=x.dropna(subset=['rate_source_date'])
        self.assertTrue((valid.rate_source_date<valid.date).all())
        self.assertTrue(pd.isna(x.rate.iloc[0]))
    def test_am_settlement(self):
        self.assertAlmostEqual(maturity('2026-10-15','2026-10-16')*365,17.5/24)
        self.assertLess(maturity('2026-10-16','2026-10-16'),0)
        self.assertAlmostEqual(maturity('2026-10-15','2026-10-16','PM')*365,1)
    def test_metrics_and_missing(self):
        d=pd.DataFrame({'close':[10,20,30],'prediction':[12,17,np.nan]})
        x=metrics(d,'prediction');self.assertEqual(x['n'],2);self.assertEqual(x['mae'],2.5);self.assertEqual(x['bias'],-.5)
        self.assertAlmostEqual(x['rmse'],np.sqrt(6.5));self.assertAlmostEqual(x['wape_pct'],100*5/30)
    def test_bootstrap_reproducible(self):
        d=pd.DataFrame({'date':pd.bdate_range('2026-01-01',periods=15),'close':10.,'pred_hv20':11.,'pred_hv60':12.})
        a=block_bootstrap(d,replicates=30);self.assertEqual(a,block_bootstrap(d,replicates=30));self.assertEqual(a['difference'],1.)

if __name__=='__main__':unittest.main(verbosity=2)
