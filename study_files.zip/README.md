# European options pricing study

Run the notebook in order to restore frozen observations, validate the pricing code, and produce results and charts. Inputs are in `data/`; results are in `results/` and figures in `figures/`. Run `python -m unittest -v` for tests or `python run_analysis.py` for the empirical study.
