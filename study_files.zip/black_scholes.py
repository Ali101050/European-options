"""European vanilla options under constant-volatility geometric Brownian motion.
Rates and volatility are decimals; time is in years; prices are per underlying unit.
Only the standard library is needed. Greeks are per unit rate/volatility change.
"""
import argparse
import json
import math
import random
from dataclasses import dataclass, asdict

@dataclass(frozen=True)
class Inputs:
    spot: float
    strike: float
    time: float
    rate: float
    volatility: float
    dividend: float = 0.0

    def __post_init__(self):
        for name, value in asdict(self).items():
            if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                raise ValueError(f'{name} must be a finite number')
        if self.spot <= 0 or self.strike <= 0:
            raise ValueError('spot and strike must be positive')
        if self.time < 0 or self.volatility < 0:
            raise ValueError('time and volatility must be nonnegative')


def _kind(kind):
    if kind not in ('call', 'put'):
        raise ValueError("kind must be 'call' or 'put'")


def cdf(x):
    return 0.5 * math.erfc(-x / math.sqrt(2))


def price(p, kind='call'):
    """Return a Black-Scholes-Merton price, including expiry and zero-vol limits."""
    _kind(kind)
    a = p.spot * math.exp(-p.dividend * p.time)
    b = p.strike * math.exp(-p.rate * p.time)
    if p.time == 0 or p.volatility == 0:
        return max(a-b, 0.0) if kind == 'call' else max(b-a, 0.0)
    v = p.volatility * math.sqrt(p.time)
    d1 = (math.log(p.spot / p.strike) + (p.rate-p.dividend+0.5*p.volatility**2)*p.time)/v
    d2 = d1-v
    # Evaluate the out-of-the-money side directly to reduce cancellation.
    if a <= b:
        call = max(0.0, a*cdf(d1)-b*cdf(d2))
        return call if kind == 'call' else call+b-a
    put = max(0.0, b*cdf(-d2)-a*cdf(-d1))
    return put+a-b if kind == 'call' else put


def greeks(p, kind='call'):
    """Theta is calendar-time decay per year; vega/rho are per change of 1.0.
    Degenerate Greeks are deliberately rejected because of boundary conventions.
    """
    _kind(kind)
    if p.time == 0 or p.volatility == 0:
        raise ValueError('Greeks require positive time and volatility')
    t, s, k, r, q, v = p.time, p.spot, p.strike, p.rate, p.dividend, p.volatility
    root = math.sqrt(t)
    d1 = (math.log(s/k)+(r-q+v*v/2)*t)/(v*root)
    d2 = d1-v*root
    eq, er = math.exp(-q*t), math.exp(-r*t)
    density = math.exp(-d1*d1/2)/math.sqrt(2*math.pi)
    z = 1 if kind == 'call' else -1
    return dict(delta=z*eq*cdf(z*d1), gamma=eq*density/(s*v*root),
                vega=s*eq*density*root,
                theta=-s*eq*density*v/(2*root)-z*r*k*er*cdf(z*d2)+z*q*s*eq*cdf(z*d1),
                rho=z*k*t*er*cdf(z*d2))


def implied_volatility(p, target, kind='call', tolerance=1e-10, max_iterations=200):
    """Bisection inversion. A price equal to its lower bound returns zero.
    The unattainable upper bound is rejected; expiry cannot identify volatility.
    """
    _kind(kind)
    if p.time == 0:
        raise ValueError('volatility is not identifiable at expiry')
    if not math.isfinite(target) or tolerance <= 0 or not math.isfinite(tolerance):
        raise ValueError('finite target and positive finite tolerance required')
    if not isinstance(max_iterations, int) or max_iterations < 1:
        raise ValueError('max_iterations must be a positive integer')
    a, b = p.spot*math.exp(-p.dividend*p.time), p.strike*math.exp(-p.rate*p.time)
    lower, upper = (max(a-b, 0), a) if kind == 'call' else (max(b-a, 0), b)
    if target < lower or target >= upper:
        raise ValueError('target lies outside finite-volatility price bounds')
    if target == lower:
        return 0.0
    def value(v):
        return price(Inputs(p.spot,p.strike,p.time,p.rate,v,p.dividend),kind)
    low, high = 0.0, 1.0
    while value(high) < target:
        high *= 2
        if high > 1024:
            raise ValueError('unable to bracket volatility')
    for _ in range(max_iterations):
        mid = (low+high)/2
        error = value(mid)-target
        if abs(error) <= tolerance:
            return mid
        if error < 0: low = mid
        else: high = mid
    raise RuntimeError('implied volatility did not converge')


def binomial(p, kind='call', steps=500):
    """European Cox-Ross-Rubinstein backward induction, O(steps^2) time."""
    _kind(kind)
    if isinstance(steps,bool) or not isinstance(steps,int) or steps < 1:
        raise ValueError('steps must be a positive integer')
    if p.time == 0 or p.volatility == 0:
        return price(p,kind)
    dt = p.time/steps
    u = math.exp(p.volatility*math.sqrt(dt))
    d = 1/u
    prob = (math.exp((p.rate-p.dividend)*dt)-d)/(u-d)
    if not 0 <= prob <= 1:
        raise ValueError('invalid tree probability; increase steps')
    z = 1 if kind == 'call' else -1
    values = [max(z*(p.spot*math.exp((2*j-steps)*math.log(u))-p.strike),0) for j in range(steps+1)]
    discount = math.exp(-p.rate*dt)
    for n in range(steps,0,-1):
        values = [discount*(prob*values[j+1]+(1-prob)*values[j]) for j in range(n)]
    return values[0]


def monte_carlo(p, kind='call', samples=100000, seed=42):
    """Exact terminal GBM sampling; normal-approximation 95% confidence interval."""
    _kind(kind)
    if isinstance(samples,bool) or not isinstance(samples,int) or samples < 2:
        raise ValueError('samples must be an integer >= 2')
    if p.time == 0 or p.volatility == 0:
        value=price(p,kind)
        return dict(estimate=value, standard_error=0.0, ci95=[value,value], samples=samples,seed=seed)
    rng = random.Random(seed)
    mean = m2 = 0.0
    sign = 1 if kind == 'call' else -1
    for n in range(1,samples+1):
        terminal=p.spot*math.exp((p.rate-p.dividend-p.volatility**2/2)*p.time+p.volatility*math.sqrt(p.time)*rng.gauss(0,1))
        value=math.exp(-p.rate*p.time)*max(sign*(terminal-p.strike),0)
        delta=value-mean
        mean += delta/n
        m2 += delta*(value-mean)
    se=math.sqrt(m2/(samples-1)/samples)
    return dict(estimate=mean,standard_error=se,ci95=[mean-1.96*se,mean+1.96*se],samples=samples,seed=seed)


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('spot','strike','time','rate','volatility'):
        parser.add_argument('--'+name,type=float,required=True)
    parser.add_argument('--dividend',type=float,default=0)
    parser.add_argument('--kind',choices=['call','put'],default='call')
    parser.add_argument('--target',type=float,help='observed price to invert')
    args=parser.parse_args()
    try:
        p=Inputs(args.spot,args.strike,args.time,args.rate,args.volatility,args.dividend)
        out={'inputs':asdict(p),'kind':args.kind,'price':price(p,args.kind)}
        if p.time > 0 and p.volatility > 0: out['greeks']=greeks(p,args.kind)
        if args.target is not None: out['implied_volatility']=implied_volatility(p,args.target,args.kind)
        print(json.dumps(out,indent=2,allow_nan=False))
    except (ValueError,OverflowError,RuntimeError) as error:
        parser.error(str(error))

if __name__ == '__main__': main()
