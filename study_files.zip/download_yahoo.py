"""Optional refresh using yfinance or Yahoo's public chart endpoint.
The frozen study is the default reproducibility route. Refresh to a NEW folder.
Yahoo can change, revise, rate-limit or remove historical option data.
"""
from pathlib import Path
import argparse,datetime,json,urllib.parse,urllib.request,csv,hashlib
from zoneinfo import ZoneInfo

SYMBOLS=[f'SPX{e}{k}{int(s*1000):08}' for e in ('261016','261218') for s in (7400,7600,7800) for k in ('C','P')]

def download(out,backend='chart',start='2026-04-01',end='2026-10-01'):
    out=Path(out)
    if (out/'data/source_manifest.json').exists():raise FileExistsError('Choose a new output folder; preserve the original snapshot.')
    data=out/'data';raw=data/'raw';raw.mkdir(parents=True,exist_ok=True)
    manifest={'retrieved_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'backend':backend,'sources':[]};option_rows=[]
    for symbol in ['^GSPC','^IRX']+SYMBOLS:
        period1=int(datetime.datetime.fromisoformat(start).replace(tzinfo=datetime.timezone.utc).timestamp())
        period2=int(datetime.datetime.fromisoformat(end).replace(tzinfo=datetime.timezone.utc).timestamp())
        url=f'https://query1.finance.yahoo.com/v8/finance/chart/{urllib.parse.quote(symbol,safe="")}?period1={period1}&period2={period2}&interval=1d'
        try:
            if backend=='yfinance':
                import yfinance as yf
                frame=yf.Ticker(symbol).history(start=start,end=end,interval='1d',auto_adjust=False,repair=False,raise_errors=True)
                if frame.empty:raise RuntimeError('empty history')
                rows=[dict(date=str(i.date()),open=float(row.Open),high=float(row.High),low=float(row.Low),close=float(row.Close),volume=float(row.Volume)) for i,row in frame.iterrows()]
                payload=frame.to_csv().encode();file=raw/(symbol.replace('^','')+'.csv')
            else:
                with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0'}),timeout=25) as response:payload=response.read()
                result=json.loads(payload)['chart']['result'][0];quotes=result['indicators']['quote'][0];rows=[]
                for j,ts in enumerate(result.get('timestamp',[])):
                    if quotes['close'][j] is None:continue
                    date=datetime.datetime.fromtimestamp(ts,ZoneInfo('America/New_York')).date().isoformat()
                    if not start<=date<end:continue
                    rows.append(dict(date=date,**{x:quotes[x][j] for x in ['open','high','low','close','volume']},source_timestamp=ts))
                file=raw/(symbol.replace('^','')+'.json')
            file.write_bytes(payload)
            if not rows:raise RuntimeError('no usable records')
            entry=dict(symbol=symbol,status='succeeded',rows=len(rows),url=url if backend=='chart' else f'https://finance.yahoo.com/quote/{urllib.parse.quote(symbol)}/history/',file=str(file.relative_to(out)),sha256=hashlib.sha256(payload).hexdigest(),retrieved_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());manifest['sources'].append(entry)
            if symbol.startswith('^'):
                target=data/('underlying.csv' if symbol=='^GSPC' else 'rates.csv')
                with target.open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=rows[0]);w.writeheader();w.writerows(rows)
            else:
                expiry=datetime.datetime.strptime(symbol[3:9],'%y%m%d').date().isoformat();kind='call' if symbol[9]=='C' else 'put';strike=int(symbol[10:])/1000
                for row in rows:
                    if row['date']<'2026-07-01':continue
                    option_rows.append(dict(contract=symbol,expiry=expiry,kind=kind,strike=strike,settlement='AM',source_url=entry['url'],source_method='Yahoo chart JSON' if backend=='chart' else 'yfinance history',**row))
            print(symbol,len(rows))
        except Exception as error:
            manifest['sources'].append(dict(symbol=symbol,status='failed',error=str(error),url=url));print(symbol,'FAILED:',error)
    if option_rows:
        keys=sorted(set().union(*(x.keys() for x in option_rows)))
        with (data/'options.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(option_rows)
    (data/'source_manifest.json').write_text(json.dumps(manifest,indent=2))
    if any(x['status']=='failed' for x in manifest['sources']):raise RuntimeError('Download incomplete; inspect source_manifest.json. No synthetic replacement is generated.')
    return out

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);p.add_argument('--backend',choices=['chart','yfinance'],default='yfinance');a=p.parse_args();download(a.out,a.backend)
